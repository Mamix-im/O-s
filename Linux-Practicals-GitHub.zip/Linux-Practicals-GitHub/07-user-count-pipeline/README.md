# Practical 7 — Display and Save Logged-in User Information

**Aim:** Display currently logged-in users and save the information and count to a file.

Run:
```bash
sh user_count_pipeline.sh
```

The output is saved in `users.txt` in the current directory.
