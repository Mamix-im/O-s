# Practical 4 — Find Common Names in Two Files

**Aim:** Display only names that appear in both files.

Create sample files:
```bash
printf 'Rahul\nAmit\nPriya\nNeha\nKaran\n' > file1.txt
printf 'Priya\nKaran\nRavi\nAmit\n' > file2.txt
sh common_names.sh
```

When prompted, enter `file1.txt` and then `file2.txt`.
