# Practical 3 — Count Lines, Words and Characters

**Aim:** Create a file and display the number of lines, words and characters in it.

Example:
```bash
printf 'Hello world\nThis is a test\n' > sample.txt
sh count_file_stats.sh
```

When prompted, enter `sample.txt`.
