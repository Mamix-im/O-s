# Practical 2 — Arithmetic Operations with Unix/Linux

**Aim:** Perform arithmetic operations on four integers.

Run:
```bash
sh arithmetic.sh
```

Enter four integers separated by spaces, for example: `6 7 3 4`.

**Journal note:** The source journal uses `expr` and prints an approximate decimal average. This script keeps that approach for matching the practical format.
