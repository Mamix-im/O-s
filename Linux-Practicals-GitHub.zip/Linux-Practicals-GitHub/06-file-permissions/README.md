# Practical 6 — Change File Permissions

**Aim:** Study and use commands for changing file permissions.

## Symbolic permission method
```bash
echo "This is a permission testing file." > modetest.txt
ls -l modetest.txt
chmod u=rw,go=rw modetest.txt
ls -l modetest.txt
```

## Octal permission method
```bash
echo "This is a permission testing file." > chmodetest.txt
ls -l chmodetest.txt
chmod 674 chmodetest.txt
ls -l chmodetest.txt
```

`r = 4`, `w = 2`, `x = 1`. For `chmod 674`, owner gets `rw-`, group gets `rwx`, and others get `r--`.

## Ownership and group commands (journal demonstration)
These commands require administrator permission and may create/change users and groups. Only run them in a lab VM when authorized:
```bash
whoami
sudo groupadd cyberlab
getent group cyberlab
sudo adduser student1
sudo adduser student2
sudo usermod -aG cyberlab student1
sudo usermod -aG cyberlab student2
cd ~
touch lab.txt
ls -l lab.txt
sudo chgrp cyberlab lab.txt
ls -l lab.txt
sudo chown student1 lab.txt
ls -l lab.txt
sudo chmod g+rw lab.txt
ls -l lab.txt
```
