# Practical 11 — Find the Smallest of Three Numbers

**Aim:** Read three numbers from the keyboard and print the smallest.

Run:
```bash
sh smallest_three.sh
```

Example input: `50 20 10`  
Expected output: `10 is the smallest`

This journal-style logic assumes the smallest value is unique; if two or more inputs are equal, use a separately improved version.
