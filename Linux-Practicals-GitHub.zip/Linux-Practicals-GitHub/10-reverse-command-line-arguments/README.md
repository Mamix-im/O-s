# Practical 10 — Reverse Command-Line Arguments

**Aim:** Accept any number of command-line arguments and print them in reverse order.

Run with sample arguments:
```bash
sh reverse_arguments.sh Apple Mango Banana Orange
```

Expected reverse order:
```text
Orange Banana Mango Apple
```
