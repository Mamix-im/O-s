# Practical 1 — Basic & User Status Unix/Linux Commands

**Aim:** Study basic and user-status Unix/Linux commands.

Run:
```bash
sh basic_user_status.sh
```

The script displays current user, user/group IDs, logged-in users, login details, date/time, hostname, working directory, OS information, uptime, shell, home directory and directory listing.
