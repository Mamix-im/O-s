# Practical 5 — Find the Inode Number of a File

**Aim:** Display the inode number of a desired file.

Run:
```bash
sh inode_number.sh
```
When prompted, enter an existing regular file name, such as `file1.txt`.
